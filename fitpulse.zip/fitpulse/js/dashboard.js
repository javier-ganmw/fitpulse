// =========================================
//  FitPulse — Dashboard Renderer
// =========================================

let stepsChartInst = null;
let calChartInst = null;

document.addEventListener('DOMContentLoaded', () => {
  setDateBadge();
  loadDashboard();
});

function setDateBadge() {
  const el = document.getElementById('dateBadge');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

async function loadDashboard() {
  showState('loading');
  try {
    const data = await fetchAllData();
    renderAll(data);
    showState('content');
  } catch (err) {
    document.getElementById('errorMsg').textContent = err.message;
    showState('error');
  }
}

function showState(state) {
  document.getElementById('loadingState').style.display = state === 'loading' ? 'flex' : 'none';
  document.getElementById('errorState').style.display = state === 'error' ? 'flex' : 'none';
  document.getElementById('dashContent').style.display = state === 'content' ? 'block' : 'none';
}

// ---- Main Render ----

function renderAll(d) {
  renderProfile(d.profile);
  renderActivity(d.activity);
  renderWeeklySteps(d.weekSteps);
  renderHeartRate(d.heartRate, d.hrv);
  renderSleep(d.sleep);
  renderVitals(d.heartRate, d.spo2, d.breathing, d.skinTemp);
  renderWeeklyCalories(d.weekCals);
  renderBody(d.weight, d.bodyFat, d.activity);
  renderInsight(d.activity, d.sleep, d.weekSteps);
}

// ---- Profile ----

function renderProfile(profile) {
  if (!profile) return;
  const u = profile.user;
  const name = u.displayName || u.fullName || 'You';
  document.getElementById('userName').textContent = name;
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  document.getElementById('userAvatar').textContent = initials;
}

// ---- Activity ----

function renderActivity(activity) {
  if (!activity) return;
  const s = activity.summary;

  const steps = s.steps || 0;
  const stepsGoal = activity.goals?.steps || 10000;
  const activeMin = (s.fairlyActiveMinutes || 0) + (s.veryActiveMinutes || 0);
  const activeMinGoal = activity.goals?.activeMinutes || 60;
  const calories = s.activityCalories || 0;
  const bmrCalories = s.caloriesOut || 0;

  setText('steps', steps.toLocaleString());
  setText('stepsGoal', stepsGoal.toLocaleString());
  setText('calories', calories.toLocaleString());
  setText('totalCalories', bmrCalories.toLocaleString());
  setText('activeMin', activeMin);

  setProgress('stepsProgress', steps / stepsGoal);
  setProgress('caloriesProgress', calories / 600);
  setProgress('activeMinProgress', activeMin / activeMinGoal);

  setText('distance', (s.distances?.find(d => d.activity === 'total')?.distance || 0).toFixed(2));
  setText('floors', s.floors || 0);

  setDelta('stepsDelta', steps, stepsGoal, 'goal');
  setDelta('activeMinDelta', activeMin, activeMinGoal, 'min goal');
}

// ---- Weekly Steps Chart ----

function renderWeeklySteps(weekSteps) {
  if (!weekSteps) return;
  const entries = weekSteps['activities-steps'] || [];
  const labels = entries.map(e => {
    const d = new Date(e.dateTime);
    return ['S','M','T','W','T','F','S'][d.getDay()];
  });
  const values = entries.map(e => parseInt(e.value) || 0);
  const today = new Date().toISOString().split('T')[0];
  const colors = entries.map((e, i) => {
    if (e.dateTime === today) return '#1D9E75';
    return values[i] >= 10000 ? '#5DCAA5' : '#9FE1CB';
  });

  const ctx = document.getElementById('stepsChart');
  if (!ctx) return;

  if (stepsChartInst) stepsChartInst.destroy();

  stepsChartInst = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: colors,
        borderRadius: 4,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: c => c.parsed.y.toLocaleString() + ' steps' } }
      },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#888780', font: { size: 11 } } },
        y: { display: false, grid: { display: false } }
      }
    }
  });
}

// ---- Heart Rate ----

function renderHeartRate(hr, hrvData) {
  if (!hr) return;
  const summary = hr['activities-heart']?.[0]?.value;
  if (!summary) return;

  const resting = summary.restingHeartRate;
  if (resting) setText('restingHR', resting);

  const zones = summary.heartRateZones || [];
  const peak = zones.find(z => z.name === 'Peak');
  const cardio = zones.find(z => z.name === 'Cardio');
  const fat = zones.find(z => z.name === 'Fat Burn');
  const rest = zones.find(z => z.name === 'Out of Range');

  const maxMins = Math.max(
    peak?.minutes || 0,
    cardio?.minutes || 0,
    fat?.minutes || 0,
    1440
  );

  setZone('zPeak', 'zPeakMin', peak, maxMins);
  setZone('zCardio', 'zCardioMin', cardio, maxMins);
  setZone('zFat', 'zFatMin', fat, maxMins);
  setZone('zRest', 'zRestMin', rest, 1440);

  // HRV
  if (hrvData?.hrv?.[0]?.value?.dailyRmssd) {
    setText('hrv', Math.round(hrvData.hrv[0].value.dailyRmssd));
  }
}

function setZone(barId, minId, zone, max) {
  if (!zone) return;
  const bar = document.getElementById(barId);
  const minEl = document.getElementById(minId);
  const mins = zone.minutes || 0;
  if (bar) bar.style.width = Math.round((mins / max) * 100) + '%';
  if (minEl) minEl.textContent = mins < 60 ? `${mins}m` : `${Math.floor(mins/60)}h ${mins%60}m`;
}

// ---- Sleep ----

function renderSleep(sleep) {
  if (!sleep?.sleep?.length) return;

  const main = sleep.sleep.find(s => s.isMainSleep) || sleep.sleep[0];
  const summary = sleep.summary;

  // Time badge
  if (main.startTime && main.endTime) {
    const start = formatTime(main.startTime);
    const end = formatTime(main.endTime);
    setText('sleepTime', `${start} – ${end}`);
  }

  // Totals
  const totalMins = summary.totalMinutesAsleep || main.minutesAsleep || 0;
  setText('sleepTotal', minsToHM(totalMins));
  setText('sleepScore', sleep.summary?.stages ? '–' : '–');

  // Sleep score (if available)
  if (main.levels?.summary) {
    const rem = main.levels.summary.rem?.minutes || 0;
    setText('sleepREM', minsToHM(rem));
  }

  // Sleep score from efficiency
  const eff = main.efficiency || 0;
  const score = Math.min(100, Math.round(eff));
  setText('sleepScore', score || '–');

  // Stages visualization
  renderSleepStages(main);
}

function renderSleepStages(main) {
  const container = document.getElementById('sleepStages');
  if (!container) return;
  container.innerHTML = '';

  const stageColors = { wake: '#85B7EB', light: '#378ADD', deep: '#185FA5', rem: '#7F77DD', asleep: '#378ADD', restless: '#85B7EB', awake: '#85B7EB' };

  const data = main.levels?.data || [];
  if (!data.length) return;

  const total = data.reduce((sum, seg) => sum + (seg.seconds || 0), 0);
  data.forEach(seg => {
    const div = document.createElement('div');
    div.className = 'stage-seg';
    const pct = ((seg.seconds || 0) / total) * 100;
    div.style.flex = pct.toFixed(1);
    div.style.background = stageColors[seg.level] || '#85B7EB';
    div.style.borderRadius = '3px';
    div.title = `${seg.level} – ${Math.round(seg.seconds / 60)} min`;
    container.appendChild(div);
  });
}

// ---- Vitals ----

function renderVitals(hr, spo2, breathing, skinTemp) {
  // Current HR (latest from intraday if available, else resting)
  const resting = hr?.['activities-heart']?.[0]?.value?.restingHeartRate;
  if (resting) {
    setText('heartRate', `${resting} bpm`);
    const badge = document.getElementById('hrBadge');
    if (badge) {
      if (resting < 60) { badge.textContent = 'Low'; badge.className = 'vital-badge warn'; }
      else if (resting <= 100) { badge.textContent = 'Normal'; badge.className = 'vital-badge good'; }
      else { badge.textContent = 'High'; badge.className = 'vital-badge bad'; }
    }
  }

  // SpO2
  const spo2Val = spo2?.value?.avg || spo2?.avg;
  if (spo2Val) {
    setText('spo2', `${Math.round(spo2Val)}%`);
    setText('spo2Vital', `${Math.round(spo2Val)}%`);
    const badge = document.getElementById('spo2Badge');
    if (badge) {
      badge.textContent = spo2Val >= 95 ? 'Optimal' : spo2Val >= 90 ? 'Low' : 'Very low';
      badge.className = 'vital-badge ' + (spo2Val >= 95 ? 'good' : 'warn');
    }
    setText('spo2', Math.round(spo2Val));
  }

  // Breathing
  const brVal = breathing?.br?.[0]?.value?.breathingRate;
  if (brVal) setText('breathRate', `${Math.round(brVal)} /min`);

  // Skin temp
  const tempVal = skinTemp?.tempSkin?.[0]?.value?.nightlyRelative;
  if (tempVal !== undefined && tempVal !== null) {
    const sign = tempVal >= 0 ? '+' : '';
    setText('skinTemp', `${sign}${tempVal.toFixed(1)} °C`);
    const badge = document.getElementById('tempBadge');
    if (badge) {
      badge.textContent = Math.abs(tempVal) <= 0.5 ? 'Normal' : 'Slightly high';
      badge.className = 'vital-badge ' + (Math.abs(tempVal) <= 0.5 ? 'good' : 'warn');
    }
  }
}

// ---- Weekly Calories Chart ----

function renderWeeklyCalories(weekCals) {
  if (!weekCals) return;
  const entries = weekCals['activities-calories'] || [];
  const labels = entries.map(e => {
    const d = new Date(e.dateTime);
    return ['S','M','T','W','T','F','S'][d.getDay()];
  });
  const values = entries.map(e => parseInt(e.value) || 0);
  const today = new Date().toISOString().split('T')[0];
  const colors = entries.map((e, i) =>
    e.dateTime === today ? '#D85A30' : '#F0997B'
  );

  const nonZero = values.filter(v => v > 0);
  const avg = nonZero.length ? Math.round(nonZero.reduce((a,b)=>a+b,0) / nonZero.length) : 0;
  const total = nonZero.reduce((a,b)=>a+b,0);

  setText('calAvg', avg.toLocaleString() + ' kcal');
  setText('calTotal', total.toLocaleString() + ' kcal');

  const ctx = document.getElementById('calChart');
  if (!ctx) return;
  if (calChartInst) calChartInst.destroy();

  calChartInst = new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: values, backgroundColor: colors, borderRadius: 4, borderSkipped: false }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: c => c.parsed.y.toLocaleString() + ' kcal' } }
      },
      scales: {
        x: { grid: { display: false }, ticks: { color: '#888780', font: { size: 11 } } },
        y: { display: false }
      }
    }
  });
}

// ---- Body Metrics ----

function renderBody(weight, bodyFat, activity) {
  if (weight?.weight?.length) {
    const w = weight.weight[0].weight;
    setText('weight', w.toFixed(1));

    // BMI from profile height (if we had it) — approximate
    const bmiEl = document.getElementById('bmi');
    if (bmiEl) bmiEl.textContent = '–';
  }
  if (bodyFat?.fat?.length) {
    setText('bodyFat', bodyFat.fat[0].fat.toFixed(1));
  }
}

// ---- Insight ----

function renderInsight(activity, sleep, weekSteps) {
  const el = document.getElementById('insightText');
  if (!el) return;

  const insights = [];

  const steps = activity?.summary?.steps || 0;
  const stepsGoal = activity?.goals?.steps || 10000;

  if (steps >= stepsGoal) {
    insights.push(`<strong>Goal crushed!</strong> You've already hit your ${stepsGoal.toLocaleString()} step goal today. Keep moving to set a new personal best.`);
  } else {
    const remaining = stepsGoal - steps;
    insights.push(`<strong>Almost there!</strong> You need ${remaining.toLocaleString()} more steps to hit your daily goal. That's about ${Math.round(remaining / 1300)} minutes of walking.`);
  }

  const sleepScore = sleep?.sleep?.[0]?.efficiency;
  if (sleepScore && sleepScore >= 85) {
    insights.push(`<strong>Great sleep!</strong> Your sleep efficiency was ${sleepScore}% — well above average. Quality rest helps your body recover and your focus stay sharp.`);
  } else if (sleepScore && sleepScore < 75) {
    insights.push(`<strong>Sleep tip:</strong> Your sleep efficiency was ${sleepScore}% last night. Try keeping a consistent bedtime and limiting screens 30 minutes before sleep.`);
  }

  const weekData = weekSteps?.['activities-steps'] || [];
  const goalDays = weekData.filter(e => parseInt(e.value) >= 10000).length;
  if (goalDays >= 4) {
    insights.push(`<strong>Consistent week!</strong> You've hit your step goal ${goalDays} of the last 7 days — great habit forming.`);
  }

  el.innerHTML = insights[0] || '<strong>Welcome!</strong> Your health data is loaded. Check back daily to track your progress.';
}

// ---- Utils ----

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function setProgress(id, ratio) {
  const el = document.getElementById(id);
  if (el) el.style.width = Math.min(100, Math.round(ratio * 100)) + '%';
}

function setDelta(id, val, goal, unit) {
  const el = document.getElementById(id);
  if (!el) return;
  const diff = val - goal;
  if (diff >= 0) {
    el.className = 'card-delta up';
    el.innerHTML = `<i class="fas fa-arrow-up"></i> +${Math.abs(diff).toLocaleString()} above ${unit}`;
  } else {
    el.className = 'card-delta down';
    el.innerHTML = `<i class="fas fa-arrow-down"></i> ${Math.abs(diff).toLocaleString()} below ${unit}`;
  }
}

function minsToHM(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function formatTime(isoStr) {
  const d = new Date(isoStr);
  return d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}
